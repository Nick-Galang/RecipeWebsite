﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore;
using Recipe.Models;


namespace Recipe
{
    public class Startup
    {
        public IConfiguration Configuration;
        public Startup(IConfiguration configuration) =>
            Configuration = configuration;
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(
                Configuration["Data:RecipeCuisines:ConnectionString"]
                ));
            services.AddTransient<ICuisineRepository, EFCusineRepository>();
            services.AddMvc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseStaticFiles();
                app.UseDeveloperExceptionPage();
            }
            app.UseStaticFiles();
            //app.UseMvcWithDefaultRoute();
            app.UseMvc(routes =>
            {
                routes.MapRoute(
               name: null,
               template: "{controller=home}/{action=index}");

                routes.MapRoute(
             name: "default",
             template: "{controller=admin}/{action=action=index}");

                //routes.MapRoute(
                //name: "default",
                //template: "{controller=Recipe}/{action=RecipeList}/{id?}");
                routes.MapRoute(
                   name: null,
                   template: "{controller}/{action}/{id?}"
                   );


            });
            RecipeSeedData.PopulateCuisine(app);
        }
        
    }
}
