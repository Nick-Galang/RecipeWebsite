﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Recipe.Models;

namespace Recipe.Controllers
{
    public class RecipeController : Controller
    {
        private ICuisineRepository repository;        
        public RecipeController(ICuisineRepository repo)
        {
            repository = repo;
        }
        public ViewResult RecipeList() => View(repository.Recipes);
        //public ViewResult Index() => View(repository.Recipes);

        public ViewResult Edit(int cuisineId) =>
            View(repository.Recipes
                .FirstOrDefault(r => r.CuisineID == cuisineId));
    }
}