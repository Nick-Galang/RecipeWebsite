﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Recipe.Models;

namespace Recipe.Controllers
{
    public class HomeController : Controller
    {
        public ViewResult Index()
        {
            return View();
        }
        public ViewResult CuisinePage()
        {

            return View();
        }
        [HttpGet]
        public ViewResult NewRecipePage()
        {
            return View();
        }
        [HttpPost]
        public ViewResult Confirmation(Cuisine cuisine)
        {
            RecipeRepository.AddRecipe(cuisine);
            return View(cuisine);
        }
       // public ViewResult RecipeListPage()
        
        private ICuisineRepository repository;
        public HomeController(ICuisineRepository repo)
        {
            repository = repo;
        }
        public ViewResult RecipeListPage() => View(repository.Recipes);
        //return View(RecipeRepository.ListofCuisine);

        
    

        [HttpGet]
        public ViewResult AddIngredients()
        {
            return View();
        }

        //public ViewResult MyView(Ingredients ingredient)
        //{
        //    IngredientsRepository.AddIngredient(ingredient);
        //    return View(ingredient);
        //}


        //public ViewResult IngredientList()
        //{
        //    return View(IngredientsRepository.List);
        //}

        public ViewResult RatingPage()
        {
            return View();
        }


    }


}