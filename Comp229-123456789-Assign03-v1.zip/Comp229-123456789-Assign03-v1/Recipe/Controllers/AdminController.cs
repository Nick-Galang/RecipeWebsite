﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Recipe.Models;

namespace Recipe.Controllers
{
    public class AdminController : Controller
    {
        private ICuisineRepository repository;
        public AdminController(ICuisineRepository repo)
        {
            repository = repo;
        }
        public ViewResult Index() => View(repository.Recipes);

        public ViewResult Edit(int cuisineId) => 
            View(repository.Recipes
                .FirstOrDefault(r => r.CuisineID == cuisineId));

        [HttpPost]
        public IActionResult Edit(Cuisine recipe)
        {
            if (ModelState.IsValid)
            {
                repository.SaveRecipe(recipe);
                TempData["message"] = $"{recipe.NameOfRecipe} has been saved!";
                return RedirectToAction("Index");
            }
            else
            {
                return View(recipe);
            }
        }
        public ViewResult Create() => View("Edit", new Cuisine());
        [HttpPost]
        public IActionResult Delete(int cuisineID)
        {
            Cuisine deletedRecipe = repository.DeleteRecipe(cuisineID);

            if(deletedRecipe != null)
            {
                TempData["message"] = $"{deletedRecipe.NameOfRecipe} was deleted!";
            }
            return RedirectToAction("index");
        }
    }
}