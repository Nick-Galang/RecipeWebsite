/* 
 *    Author: Romnick
 *    Date:   08/05/2019
 */

"use strict"; 

/* global variables */
var photoOrder = [1,2,3,4,5];
var figureCount=3;
var autoAdvance=setInterval(rightAdvance,3000);


//var a = document.getElementById("sample");
//var b="Romnick@Yahoo.com";
//var c=b.replace("@","-");
//a.innerHTML=c;
//var atPos=b.search("a");


function populateFigures(){
	var filename;
	var currentFig;
	if(figureCount===3) {
	for(var i=1;  i<4; i++)
	{ 
        filename = "css/images/IMG_0" + photoOrder[i] + ".jpg";
		currentFig=document.getElementsByTagName("img")[i-1];
		currentFig.src=filename;	
	}
	}else{
		for(var i =0; i < 5; i++){
			filename= "images/IMG_0" + photoOrder[i] + ".jpg";
			currentFig=document.getElementsByTagName("img")[i];
			currentFig.src=filename;
		}
	}
}
function next(){
	clearInterval(autoAdvance);
	rightAdvance();
}


function rightAdvance() {
   for (var i = 0; i < 5; i++) {
      if ((photoOrder[i] + 1) === 6) {
         photoOrder[i] = 1;
		 
      } else {
         photoOrder[i] += 1;
      }
      populateFigures();
   }
}


function previous() {
	clearInterval(autoAdvance);
   for (var i = 0; i < 5; i++) {
      if ((photoOrder[i] - 1) === 0) {
         photoOrder[i] = 5;
      } else {
         photoOrder[i] -= 1;
      }
      populateFigures();
   }
}


   $(document).ready(function(){
			populateFigures();
            $("#btnNext").click(function(){
	         next();
	       $("#fig4").fadeOut(600);
	       $("#fig4").fadeIn(700);
           $("#fig3").fadeOut(700);
	       $("#fig3").fadeIn(700)
	       $("#fig2").fadeOut(900);
	       $("#fig2").fadeIn(700);
         });
		 $("#btnPrevious").click(function(){
			 previous();
	  $("#fig2").fadeOut(600);
	  $("#fig2").fadeIn(700);
    $("#fig3").fadeOut(700);
	$("#fig3").fadeIn(700)
	$("#fig4").fadeOut(900);
	$("#fig4").fadeIn(700);
  });
       });
  
	

		
	
 

