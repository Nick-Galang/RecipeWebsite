﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Builder;

namespace Recipe.Models
{
    public class RecipeSeedData
    {
        public static void PopulateCuisine(IApplicationBuilder app)
        {
            ApplicationDbContext context = app.ApplicationServices
                 .GetRequiredService<ApplicationDbContext>();
            context.Database.Migrate();
            if (!context.Cuisines.Any())
            {
                context.Cuisines.AddRange(
                    new Cuisine
                    {
                        NameOfRecipe = "Chicken Adobo",
                        TypeOfCuisine = "Asian",
                        Cost = 100,
                        Time = 10
                    },
                      new Cuisine
                      {
                          NameOfRecipe = " Chapchae",
                          TypeOfCuisine = "Asian",
                          Cost = 300,
                          Time = 20
                      },
                        new Cuisine
                        {
                            NameOfRecipe = "Kebab",
                            TypeOfCuisine = "Mediterenean",
                            Cost = 50,
                            Time = 30
                        },
                        new Cuisine
                        {
                            NameOfRecipe = "Roast Beef",
                            TypeOfCuisine = "Western",
                            Cost = 50,
                            Time = 40
                        },
                        new Cuisine
                        {
                            NameOfRecipe = "Macaroni and Cheese",
                            TypeOfCuisine = "Soul Food",
                            Cost = 50,
                            Time = 30
                        }

                    );
                context.SaveChanges();
            }
        }

    }
}
