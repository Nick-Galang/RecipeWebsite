﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Recipe.Models
{
    public class IngredientsRepository
    {
       
            //private static List<Ingredients> ingredientList = new List<Ingredients>();

            //public static IEnumerable<Ingredients> List
            //{
            //    get
            //    {
            //        return ingredientList;
            //    }
            //}
            //public static void AddIngredient(Ingredients ingredient)
            //{
            //    ingredientList.Add(ingredient);
            //}
        
    }
}
