﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Recipe.Models
{
    public class EFCusineRepository : ICuisineRepository
    {
        private ApplicationDbContext context;
        
        public EFCusineRepository(ApplicationDbContext ctx)
        {
            context = ctx;

        }
        public IQueryable<Cuisine> Recipes => context.Cuisines;

        public void SaveRecipe(Cuisine recipe)
        {
            if (recipe.CuisineID == 0)
            {
                context.Cuisines.Add(recipe);
            }
            else
            {
                Cuisine recipeEntry = context.Cuisines
                    .FirstOrDefault(c => c.CuisineID == recipe.CuisineID);
                if (recipeEntry != null)
                {
                    recipeEntry.NameOfRecipe = recipe.NameOfRecipe;
                    recipeEntry.TypeOfCuisine = recipe.TypeOfCuisine;
                    recipeEntry.Cost = recipe.Cost;
                    recipeEntry.Time = recipe.Time;

                }
            }
                context.SaveChanges();
            }
        public Cuisine DeleteRecipe(int cuisineID)
        {
            Cuisine recipeEntry = context.Cuisines
               .FirstOrDefault(c => c.CuisineID == cuisineID);
            if(recipeEntry != null)
            {
                context.Cuisines.Remove(recipeEntry);
                context.SaveChanges();
            }
            return recipeEntry;
        }
           
    }
}
