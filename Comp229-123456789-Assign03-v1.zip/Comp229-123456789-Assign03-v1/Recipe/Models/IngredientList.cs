﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Recipe.Models
{
    public class IngredientList
    {
        public int IngredientListID { get; set; }

        public Cuisine Cuisine { get; set; }

        public Ingredient Ingredient { get; set; }

        public int Quantity { get; set; }
    }
}
