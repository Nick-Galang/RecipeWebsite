﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Recipe.Models
{
    public class Cuisine
    {     
        public int CuisineID { get; set; }
        public string NameOfRecipe { get; set; }
        public string TypeOfCuisine { get; set; }
        public int Cost { get; set; }
        public int Time { get; set; }
    }
}
